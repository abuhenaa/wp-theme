<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class CounterBox_Widgets extends Widget_Base {

    public function get_name() {
        return 'counter-box';
    }

    public function get_title() {
        return esc_html__('Counter Box', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-stream';
    }

    public function get_categories() {
        return ['saiful'];
    }

    protected function _register_controls() {

        $this->start_controls_section('counter_section', [
            'label' => esc_html__('Counter Box', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Great Achievement',
            'label_block' => true,
            'title' => 'Enter the section title',
                ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'counter_name', [
            'label' => esc_html__('Counter Name', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'counter_percent', [
            'label' => esc_html__('Item Number', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'counter_icon', [
            'label' => esc_html__('Set Icon', 'saiful'),
            'type' => Controls_Manager::ICONS,
            'label_block' => true,
            'default' =>[ 
                'value' => 'flaticon-layers',
                'library' => 'solid',
                ],
                ]
        );

        $this->add_control(
                'counter_box',
            [
                'label' => esc_html__('Counter Box Items', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                                [
                                'counter_name' => esc_html__('Project Complete', 'saiful'),
                                'counter_percent' => esc_html__('95', 'saiful'),
                                'counter_icon' => esc_attr( 'flaticon-layers' ),
                                ],
                                [
                                'counter_name' => esc_html__('Award Winning', 'saiful'),
                                'counter_percent' => esc_html__('12', 'saiful'),
                                'counter_icon' => esc_attr( 'flaticon-trophy' ),
                                ],
                                [
                                'counter_name' => esc_html__('Happy client', 'saiful'),
                                'counter_percent' => esc_html__('254', 'saiful'),
                                'counter_icon' => esc_attr( 'flaticon-smiling-emoticon-square-face' ),
                                ],
                                [
                                'counter_name' => esc_html__('Creative Team Member', 'saiful'),
                                'counter_percent' => esc_html__('9', 'saiful'),
                                'counter_icon' => esc_attr( 'flaticon-group' ),
                                ],
                            ],
                'title_field' => '{{{ counter_name }}}',
            ]
        );
        $this->end_controls_section();


        $this->start_controls_section(
                'counter_box_styles', [
            'label' => esc_html__('Counter Box Style', 'saiful'),
                ]
        );
        $this->add_control(
                'counter_box_color', [
            'label' => esc_html__('Box Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'label_block' => true,
            'title' => esc_html__('Select color','saiful'),
            'scheme' => [
                'type' => Scheme_Color::get_type(),
                'value' => Scheme_Color::COLOR_1,
            ],
            'selectors' =>
                [
                '{{WRAPPER}} .welcome_content h1' => 'color: {{VALUE}}',
            ],
            'default' => '#ff0066',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.


        $settings = $this->get_settings_for_display();
        ?>
        <!-- Start saiful_project section -->
        <section class="saiful_project section_padding bg_image">
            <div class="saiful_overlay"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section_title dark_title text-center">
                            <?php if ( !empty( $settings['section_title'] ) ): ?>
                                <h2><?php echo esc_html__( $settings['section_title'], 'saiful' ); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php
                    if( $settings['counter_box'] ){
                        foreach($settings['counter_box'] as $box){
                            ?>
                      <?php if ( !empty($box['counter_name'] ) ): ?>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="counter_box text-center">
                                <div class="counter_info">
                                   <?php \Elementor\Icons_Manager::render_icon( $box['counter_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    <h2><span class="counter"><?php echo esc_html__($box['counter_percent'], 'saiful'); ?></span>+</h2>
                                    <p><?php echo esc_html__( $box['counter_name'], 'saiful' ); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endif; }} ?>
                    
                </div>
            </div>
        </div>
         <script>
            /*----------------------
                Counter js
            ------------------------*/
            jQuery(document).ready(function($){
                $('.counter').counterUp({
                    delay: 60,
                    time: 2000
                  });
            });
                
        </script>
        <!-- End saiful_project section -->
        <?php
    }

}
