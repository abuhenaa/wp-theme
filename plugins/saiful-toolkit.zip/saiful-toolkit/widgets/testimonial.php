<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Testimonial_Widgets extends Widget_Base {

    public function get_name() {
        return 'testimonial';
    }

    public function get_title() {
        return esc_html__('Testimonial', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-user-check';
    }

    public function get_categories() {
        return ['saiful'];
    }

    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__( 'Testimonials', 'saiful' ),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__( 'Section Title', 'saiful' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__( 'What Client Say','saiful' ),
            'label_block' => true,
            'title' => esc_html__( 'Enter the section title','saiful' ),
                ]
        );
        $this->add_control(
                'quote_img', [
            'label' => esc_html__( 'Quotation Image', 'saiful' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );
        $this->add_control(
                'slider_layout', [
            'label' => esc_html__( 'Slider Version', 'saiful' ),
            'type' => Controls_Manager::SELECT,
            'default' => esc_html__( 'style1' ),
            'label_block' => true,
            'options' => [
                'style1' => esc_html__('Style 1', 'saiful'),
                'style2' => esc_html__('Style 2', 'saiful'),
                'style3' => esc_html__('Style 3', 'saiful'),
            ],
            'title' => esc_html__( 'Select the Slider Layout','saiful' ),
                ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'testi_desc', [
            'label' => esc_html__( 'Testimonial Description', 'saiful' ),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'testi_image', [
            'label' => esc_html__( 'Choose Image', 'saiful' ),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'testi_username', [
            'label' => esc_html__( 'Testimonial Client Name', 'saiful' ),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'testi_user_profession', [
            'label' => esc_html__( 'Testimonial Client Profession', 'saiful' ),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );

        $this->add_control(
                'testimonials', [
            'label' => esc_html__( 'Testimonials', 'saiful' ),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                    [
                    'testi_desc' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and type setting in industry. Lorem Ipsum has been the industrys standard dummy text an ever since the 1500s', 'saiful' ),
                    'testi_username' => esc_html__('It is a looking at its layout.', 'saiful'),
                    'testi_user_profession' => esc_html__('CEO & Founder', 'saiful'),
                ],
            ],
            'title_field' => '{{{ testi_username }}}',
                ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
                'testimonila_style',
                [
                    'label' => esc_html__('Testimonial Style','saiful'),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
        );
        $this->add_control(
                'section_title_color', [
            'label' => esc_html__('Section Title Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'title' => esc_html__( 'Select color','saiful' ),
            'scheme' => [
                'type' => Scheme_Color::get_type(),
                'value' => Scheme_Color::COLOR_1,
            ],
            'selectors' =>
                [
                '{{WRAPPER}} .saiful_testimonial .section_title h2' => 'color: {{VALUE}}',
            ],
            'default' => '#ffffff',
                ]
        );
        $this->add_control(
                'section_title_border_color', [
            'label' => esc_html__('Section Title Border Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'title' => esc_html__( 'Select color','saiful' ),
            'scheme' => [
                'type' => Scheme_Color::get_type(),
                'value' => Scheme_Color::COLOR_1,
            ],
            'selectors' =>
                [
                '{{WRAPPER}} .saiful_testimonial .section_title h2:after' => 'background-color: {{VALUE}}',
            ],
            'default' => '#ff0066',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.
        $settings = $this->get_settings_for_display();
        $slider_layout = $settings['slider_layout'];
        $slider_layout == 'style1' ? $slider = 'client_slider' : $slider = 'client_slider_2';
        $slider_layout == 'style3' ? $testi_class = 'saiful_testimonial_2 gray_bg' : $testi_class = 'dark_bg';
        ?>

        <!-- Start saiful_testimonial section -->
        <div class="saiful_testimonial saiful_testimonial_1 section_padding <?php echo esc_attr( $testi_class );?>">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section_title dark_title text-center">
                            <?php if ( !empty( $settings['section_title'] ) ): ?>
                                <h2><?php echo esc_html__( $settings['section_title'], 'saiful' ); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="<?php esc_attr_e( $slider );?>">
                        <?php
                            if( $settings['testimonials'] ){
                            foreach( $settings['testimonials'] as $testimonial ){
                        ?>
                            <div class="single_review">
                                <div class="client_box">
                                    <?php 
                                        if( $slider_layout == 'style2' ){
                                           ?>
                                            <div class="client_img">
                                               <?php 
                                                $url = $testimonial['testi_image']['url'];
                                                ?>
                                                <img src="<?php echo esc_url( $url ); ?>" class="img-fluid" alt="" >
                                                
                                            </div>
                                        <?php
                                            }
                                        ?>
                                    <?php if( $slider_layout == 'style1' || $slider_layout == 'style3'){
                                        ?>
                                          
                                    <div class="client_text">
                                        <?php
                                        $url = $settings['quote_img']['url'];
                                        ?>
                                       
                                        <img src="<?php echo esc_url( $url ); ?>" class="img-fluid" alt="" >
                                    
                                        <p><?php echo esc_html__( $testimonial['testi_desc'],'saiful' );?></p>
                                        <div class="author_info">
                                            <h4><?php echo esc_html__( $testimonial['testi_username'],'saiful' );?></h4>
                                            <p><?php echo esc_html__( $testimonial['testi_user_profession'],'saiful');?></p>
                                        </div>
                                    </div>  
                                    <?php
                                    }?>
                                    <?php if( $slider_layout == 'style2' ){
                                        ?>
                                    
                                    <div class="client_text">
                                        <div class="client_info">
                                            <h4><?php echo esc_html__( $testimonial['testi_username'],'saiful' );?></h4>
                                            <p><?php echo esc_html__( $testimonial['testi_user_profession'],'saiful');?></p>
                                        </div>
                                        <div class="review_text">
                                            <p><?php echo esc_html__( $testimonial['testi_desc'],'saiful');?></p>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php }} ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            <?php
                if( $slider_layout == 'style1' || $slider_layout == 'style3' ){
                    $autoplay = 'false';
                }else{
                    $autoplay = 'true';
                }
            ?>
            jQuery(document).ready(function($){
                $('.<?php esc_attr_e( $slider ); ?>').slick({
                    autoplay: false,
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    speed: 400,
                    dots: false,
                    arrows: <?php esc_attr_e( $autoplay ) ?>
                });
                })
    </script>
        <!-- End saiful_testimonial section -->
        <?php
    }

}
