<?php
namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
/* 
 * What we do Elementor custom Widget
 */


if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class WWD_Widgets extends Widget_Base {

    public function get_name() {
        return 'what_we_do';
    }

    public function get_title() {
        return esc_html__('What We Do', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-project-diagram';
    }

    public function get_categories() {
        return ['saiful'];
    }

    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__('What We Do', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'What We Do?',
            'label_block' => true,
            'title' => 'Enter the section title',
                ]
        );
        $this->add_control(
                'section_style', [
            'label' => esc_html__('Section Style', 'saiful'),
            'type' => Controls_Manager::SELECT,
            'default' => 'dark',
            'label_block' => true,
            'title' => 'Select Section Style',
            'options' => [
                    'dark'  => esc_html__( 'Dark', 'saiful' ),
                    'light' => esc_html__( 'Light', 'saiful' ),
            ],
                ]
        );
        $this->end_controls_section();
        
        $this->start_controls_section(
                'wwd_item',[
                    'label' => esc_html__('Items', 'saiful'),
                ]
        );
        
        $repeater = new \Elementor\Repeater();

       $repeater->add_control(
                'title',[
                    'label' => esc_html__('Title', 'saiful'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter Title', 'saiful'),
                    'default' => esc_html__('Digital Marketing', 'saiful'),
                ]
        );
        $repeater->add_control(
                'description',[
                    'label' => esc_html__('Description', 'saiful'),
                    'type' => Controls_Manager::TEXTAREA,
                    'label_block' => true,
                    'title' => esc_html__('Enter Description', 'saiful'),
                    'default' => esc_html__('Lorem Ipsum is simply dummy text of the type setting', 'saiful'),
                ]
        );
        $repeater->add_control(
                'icon',[
                    'label' => esc_html__('Icon Class Name', 'saiful'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter Icon Class Name', 'saiful'),
                    'default' => 'flaticon-loudspeaker',
                ]
        );
        $this->add_control(
        'items', [
            'label' => esc_html__('What We Do Items', 'saiful'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                    [
                    'title' => esc_html__('Digital Marketing', 'saiful'),
                    'description' => esc_html__('Lorem Ipsum is simply dummy text of the type setting', 'saiful'),
                    'icon' => 'flaticon-loudspeaker',
                ],
            ],
        'title_field' => '{{{ title }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
                'wwd_styles', [
            'label' => esc_html__('What We Do Style', 'saiful'),
            'tab' => Controls_Manager::TAB_STYLE,
                ]
        );
        
        $this->add_control(
                'section_title_color', [
            'label' => esc_html__('Section Title Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'title' => 'Select color',
            'scheme' => [
                'type' => Scheme_Color::get_type(),
                'value' => Scheme_Color::COLOR_1,
            ],
            'selectors' =>
                [
                '{{WRAPPER}} .saiful_about .saiful_content_box h2' => 'color: {{VALUE}}',
            ],
            'default' => '#01040a',
                ]
        );
        $this->add_control(
                'about_color_scheme', [
            'label' => esc_html__('Color Scheme', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .saiful_about_1 .counter_box:hover .counter_info i, .saiful_about_1 .counter_box:hover .counter_info h3' => 'color: {{VALUE}};',
                '{{WRAPPER}} .saiful_about .saiful_content_box h2:after,.saiful_btn:hover, .saiful_btn:focus,.button_box .saiful_btn' => 'background-color: {{VALUE}};',
            ],
            'default' => '#ff0066',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.

        $settings = $this->get_settings_for_display();
        $wwd_style = 'saiful_what_we_1';
        $dark_bg = ' dark_bg';
        $dark_title = ' dark_title';
        $settings['section_style'] == 'dark' ? $wwd_style = 'saiful_what_we_1' : $wwd_style = 'saiful_what_we_2';
        $settings['section_style'] == 'dark' ? $dark_bg = ' dark_bg' : $dark_bg = '';
        $settings['section_style'] == 'dark' ? $dark_title = ' dark_title' : $dark_title = '';
        ?>

        <!-- Start saiful_what_we section -->
        <div class="saiful_what_we <?php esc_attr_e( $wwd_style ); ?> section_padding<?php esc_attr_e( $dark_bg ); ?>">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section_title<?php esc_attr_e( $dark_title ); ?> text-center">
                            <?php if (!empty($settings['section_title'])): ?>
                                <h2><?php echo esc_html__($settings['section_title'], 'saiful'); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                <?php 
                    if( $settings['items'] ){
                        foreach( $settings['items'] as $item  ){
                            ?>
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="grid_item wow slideInUp">
                                <div class="grid_inner_item">
                                    <div class="saiful_icon">
                                        <i class="<?php echo esc_attr( $item['icon'] );?>"></i>
                                    </div>
                                    <div class="saiful_info">
                                        <h4><?php echo esc_html__( $item['title'],'saiful' );?></h4>
                                        <p><?php echo esc_html__( $item['description'],'saiful' );?></p>
                                    </div>
                                </div>
                            </div>
                        </div> 
                <?php 
                        }
                    }
                ?> 
                </div>
            </div>
        </div>
        <!-- End saiful_what_we section -->

        <?php
    }

}

