<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Core\Schemes;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Saiful_Services_Widgets extends Widget_Base {

    public function get_name() {
        return 'saiful_services';
    }

    public function get_title() {
        return esc_html__('Services', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-luggage-cart';
    }
    public function get_categories() {
        return ['saiful'];
    }
    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__('Saiful Services', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Great Services','saiful'),
            'label_block' => true,
            'title' => esc_html__('Enter the section title','saiful'),
                ]
        );
        $this->add_control(
                'layout_version', [
            'label' => esc_html__('Layout Version', 'saiful'),
            'type' => Controls_Manager::SELECT,
            'default' => 'v1',
            'options' => [
                'v1' => esc_html__('Version 1','saiful'),
                'v2' => esc_html__('Version 2','saiful'),
            ],
            'title' => esc_html__('Choose Section Layout Version','saiful'),
                ]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'service_icon', [
            'label' => esc_html__('Set Icon', 'saiful'),
            'type' => Controls_Manager::ICONS,
            'label_block' => true,
            'default' =>[ 
                'value' => 'flaticon-line-chart',
		'library' => 'solid',
                    
                ],
                ]
        );
        $repeater->add_control(
                'service_title', [
            'label' => esc_html__('Service Title', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'service_image', [
            'label' => esc_html__('Choose Image', 'shamko'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'service_description', [
            'label' => esc_html__('Service Description', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'service_link', [
            'label' => esc_html__('Service Link', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );

        $this->add_control(
                'service',
            [
                'label' => esc_html__('Services', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                        [
                        'service_icon' => esc_attr__( 'fas fa-pencil-ruler', 'saiful' ),
                        'service_title' => esc_html__('Digital Marketing', 'saiful'),
                        'service_description' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.', 'saiful'),
                        'service_link' => esc_html__('#', 'saiful'),
                    ],
            ],
            'title_field' => '{{{ service_title }}}',
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'service_styles',
                [
                    'label' => esc_html__( 'Service Styling', 'saiful' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
             );
        $this->add_control(
                'section_title_color',
                [
                    'label' => esc_html__('Section Title Color', 'saiful'),
                    'type' => Controls_Manager::COLOR,
                    'title' => esc_html__('Select color','saiful'),
                    'scheme' => [
                        'type' => Scheme_Color::get_type(),
                        'value' => Scheme_Color::COLOR_1,
                ],
                    'selectors' =>
                        [
                        '{{WRAPPER}} .saiful_service .section_title h2' => 'color: {{VALUE}}',
                ],
                'default' => '#04040d',
                    ]
            );
            $this->add_control(
                    'icon_color',
                    [
                        'label' => esc_html__( 'Icon Color', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_service_1 .grid_inner_item .saiful_icon i,.saiful_service .section_title h2:after,.saiful_service .grid_inner_item .saiful_info a.btn_link' => 'color: {{VALUE}};',
                        ],
                        'default'   => '#ff0066',
                    ]
            );
            $this->add_control(
                    'title_color',
                    [
                        'label' => esc_html__( 'Title Color', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_service .grid_inner_item .saiful_info h4' => 'color: {{VALUE}};',
                        ], 
                        'default'   => '#04040d',
                    ]
                       
            );
            $this->add_control(
                    'desc_color',
                    [
                        'label' => esc_html__( 'Description Color', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_service .grid_inner_item .saiful_info p' => 'color: {{VALUE}};',
                        ],
                        'default'   => '#7a7d8a',
                    ]
            );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.

        $settings = $this->get_settings_for_display();
        $layout = $settings['layout_version'];
        $version = 'saiful_service_1';
        $layout == 'v1' ? $version = 'saiful_service_1' : $version = 'saiful_service_2';
        ?>

        <!-- Start saiful_service section -->
        <div class="saiful_service <?php echo esc_attr( $version );?> section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section_title text-center">
                           <?php if (!empty($settings['section_title'])): ?>
                                <h2><?php echo esc_html__($settings['section_title'], 'saiful'); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php
                        if($settings['service']){
                            foreach($settings['service'] as $service){
                                ?>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="grid_item wow slideInUp">
                                    <div class="grid_inner_item">
                                        <?php  if( $settings['layout_version']== 'v1' ){
                                            ?>
                                            <div class="saiful_icon">
                                                <?php \Elementor\Icons_Manager::render_icon( $service['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            </div>
                                        <?php
                                        }
                                        ?>
                                        <?php 
                                        if( $settings['layout_version']== 'v2' ){
                                            $image_url = $service['service_image']['url'];
                                        echo '<div class="saiful_img">
                                                <img src="'. esc_url( $image_url ).'" class="img-fluid" alt="">
                                            </div>';
                                        }
                                         ?>
                                        <div class="saiful_info">
                                            <h4><?php echo esc_html__( $service['service_title'],'saiful' );?></h4>
                                            <p><?php echo esc_html__( $service['service_description'],'saiful' );?></p>
                                            <?php 
                                             if( $settings['layout_version']== 'v2' ){
                                                 echo '<a href="'. esc_url( $service['service_link']['url'] ).'" class="btn_link"><i class="fas fa-arrow-right"></i></a>';
                                             }
                                             ?>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php 
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
        <!-- End saiful_service section -->
        <?php
    }

}
