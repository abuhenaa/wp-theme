<?php
namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Core\Schemes;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class About_Us_Widgets extends Widget_Base {

    public function get_name() {
        return 'about_us';
    }

    public function get_title() {
        return esc_html__('About', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-user-secret';
    }

    public function get_categories() {
        return ['saiful'];
    }

    protected function _register_controls() {

        $this->start_controls_section('about_info', [
            'label' => esc_html__('About', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Introduction About Us','saiful'),
            'label_block' => true,
            'title' => esc_html__( 'Enter the section title','saiful' ),
                ]
        );
        $this->add_control(
                'layout_version', [
            'label' => esc_html__('Layout Version', 'saiful'),
            'type' => Controls_Manager::SELECT,
            'default' => 'style1',
            'label_block' => true,
            'title' => esc_html__('Select the section layout','saiful'),
            'options' => [
                'style1' => 'Style 1',
                'style2' => 'Style 2',
            ],
                ]
        );
        
        $this->add_control(
                'about_image', [
            'label' => esc_html__('Choose Image', 'saiful'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );
        $this->add_control(
                'about_desc', [
            'label' => esc_html__('About Description', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
            'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry\'s standard dummy text ever since the ads, when and unknown the printer took a galley of type and scrambled it to make a type specimen book. It has been survived not only five centuries.',
                ]
        );
        
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
                'feature_description', [
            'label' => esc_html__('Service Description', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'feature_title', [
            'label' => esc_html__('Service Title', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'feature_icon', [
            'label' => esc_html__('Set Icon', 'saiful'),
            'type' => Controls_Manager::ICONS,
            'label_block' => true,
            'default' =>[ 
                'value' => 'flaticon-line-chart',
                'library' => 'solid',
                ],
                ]
        );
        $this->add_control(
                'about_feature',
            [
                'label' => esc_html__('Special Features', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'layout_version' => 'style2',
                ],
                'default' => [
                        [
                        'feature_icon' => esc_attr__( 'flaticon-start-up', 'saiful' ),
                        'feature_title' => esc_html__('Smart Concept', 'saiful'),
                        'feature_description' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.', 'saiful'),
                    ],
            ],
            'title_field' => '{{{ feature_title }}}',
                ]
        );
        $this->add_control(
                'know_more_button', [
            'label' => esc_html__('Know More Button Text', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
            'default' => 'Know More',
                ]
        );
        $this->add_control(
                'know_more_link', [
            'label' => esc_html__('Link', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
            'default' =>[
                'url' => '#',
            ],
                ]
        );
        $this->end_controls_section();
        
        $this->start_controls_section(
                'counter_about',[
                    'label' => esc_html__('About Us Counter', 'saiful'),
                    'condition' => [
                        'layout_version' => 'style1',
                    ],
                ]
        );
        $this->add_control(
              'about_counter_1', [
          'label' => esc_html__('Counter 1 Text', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => esc_html__('Satisfied Customer', 'saiful'),
              ]
        );   
        $this->add_control(
              'about_counter_1_number', [
          'label' => esc_html__('Counter 1 Max Number', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => '500',
              ]
        );   
        $this->add_control(
              'about_counter_1_icon', [
          'label' => esc_html__('Counter 1 Icon', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' =>  'flaticon-smiling-emoticon-square-face',
              ]
         );   
        $this->add_control(
              'about_counter_2', [
          'label' => esc_html__('Counter 2 Text', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => esc_html__('Project Complete', 'saiful'),
              ]
        );   
        $this->add_control(
              'about_counter_2_number', [
          'label' => esc_html__('Counter 2 Max Number', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => '200',
              ]
        );   
        $this->add_control(
              'about_counter_2_icon', [
          'label' => esc_html__('Counter 2 Icon', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => 'flaticon-layers',
              ]
         );   
        $this->add_control(
              'about_counter_3', [
          'label' => esc_html__('Counter 3 Text', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => esc_html__('Award Winning', 'saiful'),
              ]
        );   
        $this->add_control(
              'about_counter_3_number', [
          'label' => esc_html__('Counter 3 Max Number', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => '100',
              ]
        );   
        $this->add_control(
              'about_counter_3_icon', [
          'label' => esc_html__('Counter 3 Icon', 'saiful'),
          'type' => Controls_Manager::TEXT,
          'dynamic' => [
              'active' => true,
          ],
          'label_block' => true,
          'default' => 'flaticon-trophy',
              ]
         );   
        $this->end_controls_section();

        $this->start_controls_section(
                'service_styles', [
            'label' => esc_html__('About Us Style', 'saiful'),
            'tab' => Controls_Manager::TAB_STYLE,
                ]
        );
        
        $this->add_control(
                'section_title_color', [
            'label' => esc_html__('Section Title Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'title' => 'Select color',
            'scheme' => [
                'type' => Scheme_Color::get_type(),
                'value' => Scheme_Color::COLOR_1,
            ],
            'selectors' =>
                [
                '{{WRAPPER}} .saiful_about .saiful_content_box h2' => 'color: {{VALUE}}',
            ],
            'default' => '#01040a',
                ]
        );
        $this->add_control(
                'about_color_scheme', [
            'label' => esc_html__('Color Scheme', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .saiful_about_1 .counter_box:hover .counter_info i,.saiful_about .counter_box:hover .counter_info h3' => 'color: {{VALUE}};',
            ],
            'default' => '#ff0066',
                ]
        );
        $this->add_control(
                'button_bgcolor', [
            'label' => esc_html__('Button Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .saiful_about .saiful_content_box .content_title h2:after,.saiful_about .saiful_content_box .button_box a.saiful_btn' => 'background-color: {{VALUE}};',
            ],
            'default' => '#ff0066',
                ]
        );
        $this->add_control(
                'icon_bgcolor', [
            'label' => esc_html__('Icon BG Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .saiful_about_2 .saiful_content_list .single_list .list_icon i' => 'background-color: {{VALUE}};',
            ],
            'default' => '#ff0066',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        // get our input from the widget settings.
        $settings = $this->get_settings_for_display();
        $layout_version = 'saiful_about_1';
        $style = $settings['layout_version'];
        $style == 'style1' ? $layout_version = 'saiful_about_1' : $layout_version = 'saiful_about_2 gray_bg';
        $column1 = '5';
        $column2 = '7';
        $style == 'style1' ? $column1 = '5' : $column1 = '6';
        $style == 'style2' ? $column2 = '6' : $column2 = '7';
        ?>

        <!-- Start saiful_about section -->
        <div class="saiful_about <?php esc_attr_e( $layout_version ); ?> section_padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-<?php esc_attr_e( $column1 ); ?>">
                        <div class="saiful_img_box about_img_box">
                            <div class="saiful_img">
                                <?php if ( !empty($settings['about_image'] ) ): ?>
                                    <?php $url = $settings['about_image']['url']; ?>
                                    <img src="<?php echo esc_url( $url ); ?>" class="img-fluid" alt="About Us">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-<?php esc_attr_e( $column2 ); ?>">
                        <div class="saiful_content_box about_content_box">
                            <div class="content_title">
                                <?php if ( !empty( $settings['section_title'] ) ): ?>
                                    <h2><?php echo esc_html__( $settings['section_title'], 'saiful' ); ?></h2>
                                <?php endif; ?>
                            </div>
                            <div class="content_text">
                                <?php if ( !empty( $settings['about_desc'] ) ): ?>
                                    <p><?php echo esc_html__( $settings['about_desc'], 'saiful' ); ?></p>
                                <?php endif; ?>
                            </div>
                           
                            <div class="counter_area">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <div class="counter_box">
                                            <div class="counter_info">
                                                <?php if ( !empty( $settings['about_counter_1_icon'] ) ): ?>
                                                 <i class="<?php echo esc_attr__( $settings['about_counter_1_icon'] ); ?>"></i>
                                                <?php endif; ?>
                                                <?php if ( !empty( $settings['about_counter_1_number'] ) ): ?>
                                                    <h3><span class="counter"><?php echo esc_html__( $settings['about_counter_1_number'], 'saiful' ); ?></span>+</h3>
                                                <?php endif; ?>
                                                <?php if ( !empty( $settings['about_counter_1'] ) ): ?>
                                                    <p><?php echo esc_html__( $settings['about_counter_1'], 'saiful' ); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <div class="counter_box">
                                            <div class="counter_info">
                                                <?php if ( !empty( $settings['about_counter_2_icon'] ) ): ?>
                                                 <i class="<?php echo esc_attr__( $settings['about_counter_2_icon'] ); ?>"></i>
                                                <?php endif; ?>
                                               
                                                <?php if ( !empty( $settings['about_counter_2_number'] ) ): ?>
                                                    <h3><span class="counter"><?php echo esc_html__( $settings['about_counter_2_number'], 'saiful' ); ?></span>+</h3>
                                                <?php endif; ?>
                                               
                                                 <?php if ( !empty( $settings['about_counter_2'] ) ): ?>
                                                    <p><?php echo esc_html__( $settings['about_counter_2'], 'saiful' ); ?></p>
                                                <?php endif; ?>
                                              
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <div class="counter_box">
                                            <div class="counter_info">
                                                <?php if ( !empty( $settings['about_counter_3_icon'] ) ): ?>
                                                 <i class="<?php echo esc_attr__( $settings['about_counter_3_icon'] ); ?>"></i>
                                                <?php endif; ?>
                                               
                                                <?php if ( !empty( $settings['about_counter_3_number'] ) ): ?>
                                                    <h3><span class="counter"><?php echo esc_html__( $settings['about_counter_3_number'], 'saiful' ); ?></span>+</h3>
                                                <?php endif; ?>
                                               
                                                 <?php if ( !empty( $settings['about_counter_3'] ) ): ?>
                                                    <p><?php echo esc_html__( $settings['about_counter_3'], 'saiful' ); ?></p>
                                                <?php endif; ?>
                                              
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                if($style != 'style2' ){
                            ?>
                            <div class="button_box">
                                 <?php
                                if ( !empty($settings['know_more_button']) ):

                                    $external_link = $settings['know_more_link']['is_external'] ? 'target="_blank"' : '';
                                    $nofollow_link = $settings['know_more_link']['nofollow'] ? 'rel="nofollow"' : '';
                                    ?>
                                    <a href="<?php echo esc_url($settings['know_more_link']['url']) ? esc_url($settings['know_more_link']['url']) : '#'; ?>" <?php echo esc_attr( $external_link ) . esc_attr( $nofollow_link ); ?> class="saiful_btn active_btn"><?php echo esc_html__( $settings['know_more_button'], 'saiful' ); ?></a>
                                <?php endif; ?>
                            </div>
                                <?php } ?>
                        </div>
                         <?php 
                            if( $style == 'style2' ){
                                echo '<div class="saiful_content_list">';
                                    if( $settings['about_feature'] ){
                                       foreach( $settings['about_feature'] as $feature ){
                                        echo '<div class="single_list">
                                                <div class="list_icon">';
                                           ?>
                                           <?php \Elementor\Icons_Manager::render_icon( $feature['feature_icon'], [ 'aria-hidden' => 'true' ] );?>
                                                <?php echo '</div>
                                                <div class="list_info">
                                                    <h4>'. esc_html( $feature['feature_title'],'saiful' ).'</h4>
                                                    <p>'. esc_html( $feature['feature_description'],'saiful' ).'</p>
                                                </div>
                                            </div>';
                                       } 
                                    }
                                echo '</div>';
                                  
                            }
                                    ?>
                    </div>
                </div>
            </div>
        </div><!-- End saiful_about_us section -->
        <?php
        if( $style == 'style1'){
            ?>
        
        <script>
            /*----------------------
                Counter js
            ------------------------*/
            jQuery(document).ready(function($){
                $('.counter').counterUp({
                    delay: 60,
                    time: 2000
                  });
            });
                
        </script>
        <?php
        }
        ?>
        <?php
    }

}
