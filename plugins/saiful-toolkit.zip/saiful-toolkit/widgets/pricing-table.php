<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Pricing_Table_Widgets extends Widget_Base {

    public function get_name() {
        return 'saiful_pricing_table';
    }

    public function get_title() {
        return esc_html__('Pricing Table', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-table';
    }
    public function get_categories() {
        return ['saiful'];
    }
    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__('Pricing Table', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Pricing Plan','saiful'),
            'label_block' => true,
            'title' => esc_html__('Enter the section title','saiful'),
                ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'plan_name', [
            'label' => esc_html__('Plan Name', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'plan_price', [
            'label' => esc_html__('Plan Price', 'shamko'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'default' => '39',
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'per_time', [
            'label' => esc_html__('Per Year/Month', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'features', [
            'label' => esc_html__('Tell about your feature', 'saiful'),
            'type' => Controls_Manager::WYSIWYG,
            'defualt' => '<ul>
                            <li>Advance theme option</li>
                            <li>Visual page Builder</li>
                            <li>SIngle Click Demo Import</li>
                            <li>Lifetime Free Support</li>
                            <li>6 Months Free Support</li>
                        </ul>',
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'buy_now_txt', [
            'label' => esc_html__('Buy Now Button Text', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'buy_now_url', [
            'label' => esc_html__('Buy Now Button Url', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );

        $this->add_control(
                'price_tables',
            [
                'label' => esc_html__('Price Tables', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                        [
                        'plan_name' => esc_html__('Basic Plan', 'saiful'),
                        'plan_price' => esc_html__('$39', 'saiful'),
                        'per_time' => esc_html__('month', 'saiful'),
                        'features' => esc_html__('', 'saiful'),
                        'buy_now_txt' => esc_html__('PURCHASE NOW', 'saiful'),
                        'buy_now_url' => esc_html__('#', 'saiful'),
                    ],
            ],
            'title_field' => '{{{ plan_name }}}',
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'plan_styles',
                [
                    'label' => esc_html__( 'Pricing Styling', 'saiful' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
             );
        $this->add_control(
                'section_title_color',
                [
                    'label' => esc_html__('Section Title Color', 'saiful'),
                    'type' => Controls_Manager::COLOR,
                    'title' => esc_html__('Select color','saiful'),
                    'scheme' => [
                        'type' => Scheme_Color::get_type(),
                        'value' => Scheme_Color::COLOR_1,
                ],
                    'selectors' =>
                        [
                        '{{WRAPPER}} .saiful_pricing .section_title h2' => 'color: {{VALUE}}',
                ],
                'default' => '#04040d',
                    ]
            );
        $this->add_control(
                'section_title_border_color', [
            'label' => esc_html__('Section Title Border Color', 'saiful'),
            'type' => Controls_Manager::COLOR,
            'label_block' => true,
            'title' => esc_html__( 'Select color','saiful' ),
            'scheme' => [
                'type' => Scheme_Color::get_type(),
                'value' => Scheme_Color::COLOR_1,
            ],
            'selectors' =>
                [
                '{{WRAPPER}} .saiful_pricing .section_title h2:after' => 'background-color: {{VALUE}}',
            ],
            'default' => '#ff0066',
                ]
        );
            $this->add_control(
                    'color_scheme',
                    [
                        'label' => esc_html__( 'Color Scheme', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_pricing .saiful_btn' => 'background-color: {{VALUE}};',
                                '{{WRAPPER}} .saiful_pricing .pricing_top span.plan_title' => 'color: {{VALUE}}',
                        ],
                        'default'   => '#ff0066',
                    ]
            );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.

        $settings = $this->get_settings_for_display();
        ?>
        <!-- Start saiful_pricing section -->
        <div class="saiful_pricing saiful_pricing_1 section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section_title text-center">
                             <?php if ( !empty( $settings['section_title'] ) ): ?>
                                <h2><?php echo esc_html__( $settings['section_title'], 'saiful' ); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php
                    if( $settings['price_tables'] ){
                        foreach( $settings['price_tables'] as $table ){
                            ?>
                    
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="pricing_table text-center wow slideInUp" data-wow-delay=".10s">
                            <div class="pricing_top">
                        <span class="plan_title"><?php echo esc_html__( $table['plan_name'],'saiful' );?></span>
                                <h2 class="price"><?php echo esc_html__( $table['plan_price'],'saiful' );?><span>/<?php echo esc_html__( $table['per_time'],'saiful' );?></span></h2>
                            </div>
                            <div class="pricing_body">
                                <?php echo /*Not escaped to show html content from WYSIWIG*/ $table['features'];?>
                                
                            </div>
                            <div class="pricing_button">
                                <a href="<?php echo esc_url( $table['buy_now_url']['url'] );?>" class="saiful_btn"> <?php echo esc_html__( $table['buy_now_txt'],'saiful' );?></a>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- End saiful_pricing section -->
        <?php
    }

}
