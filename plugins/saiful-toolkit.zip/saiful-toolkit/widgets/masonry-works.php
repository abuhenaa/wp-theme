<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Masonry_Works_Widgets extends Widget_Base {

    public function get_name() {
        return 'saiful_masonry';
    }

    public function get_title() {
        return esc_html__('Masonry Works', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-grip-horizontal';
    }
    public function get_categories() {
        return ['saiful'];
    }
    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__('Masonry Works', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Featured Works','saiful'),
            'label_block' => true,
            'title' => esc_html__('Enter the section title','saiful'),
                ]
        );
        $this->add_control(
                'all_work', [
            'label' => esc_html__('ALl Work Text', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('See All Works','saiful'),
            'label_block' => true,
            'title' => esc_html__('Set the all works link','saiful'),
                ]
        );
        $this->add_control(
                'all_work_link', [
            'label' => esc_html__('ALl Work Link', 'saiful'),
            'type' => Controls_Manager::URL,
            'default' => [
                'url' => '#'
            ],
            'label_block' => true,
            'title' => esc_html__('Set the all works link','saiful'),
                ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'work_title', [
            'label' => esc_html__('Work Title', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'work_subtitle', [
            'label' => esc_html__( 'Work Subtitle', 'saiful' ),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'work_width', [
            'label' => esc_html__( 'Work Item Width', 'saiful' ),
            'type' => Controls_Manager::SELECT,
            'options' => [
                '3' => esc_html__('25%','saiful'),
                '6' => esc_html__('50%','saiful'),
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'work_image', [
            'label' => esc_html__('Choose Image', 'shamko'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );

        $this->add_control(
                'works',
            [
                'label' => esc_html__('Masonry Works', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                        [
                        'work_image' => \Elementor\Utils::get_placeholder_image_src(),
                        'work_title' => esc_html__('Landing Page', 'saiful'),
                        'work_subtitle' => esc_html__('Creative Web Design', 'saiful'),
                    ],
            ],
            'title_field' => '{{{ work_title }}}',
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'masonry_styles',
                [
                    'label' => esc_html__( 'Masonry Works Styling', 'saiful' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
             );
        $this->add_control(
                'section_title_color',
                [
                    'label' => esc_html__('Section Title Color', 'saiful'),
                    'type' => Controls_Manager::COLOR,
                    'title' => esc_html__('Select color','saiful'),
                    'scheme' => [
                        'type' => Scheme_Color::get_type(),
                        'value' => Scheme_Color::COLOR_1,
                ],
                    'selectors' =>
                        [
                        '{{WRAPPER}} .saiful_work .section_title h2' => 'color: {{VALUE}}',
                ],
                'default' => '#fff',
                    ]
            );
        $this->add_control(
                'item_overlay',
                [
                    'label' => esc_html__('Work Overlay Color', 'saiful'),
                    'type' => Controls_Manager::COLOR,
                    'title' => esc_html__('Select color','saiful'),
                    'scheme' => [
                        'type' => Scheme_Color::get_type(),
                        'value' => Scheme_Color::COLOR_1,
                ],
                    'selectors' =>
                        [
                        '{{WRAPPER}} .saiful_work .masonry_grid .saiful_img .overlay_img' => 'background-color: {{VALUE}}',
                ],
                'default' => '#ff0066',
                    ]
            );
            $this->add_control(
                    'color_scheme',
                    [
                        'label' => esc_html__( 'Color Scheme', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_work .section_title h2:after' => 'background-color: {{VALUE}};',
                        ],
                        'default'   => '#ff0066',
                    ]
            );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.

        $settings = $this->get_settings_for_display();
        ?>



        <!-- Start saiful_work section -->
        <div class="saiful_work section_padding dark_bg" id="work_masonry">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section_title dark_title text-center">
                           <?php if (!empty($settings['section_title'])): ?>
                                <h2><?php echo esc_html__($settings['section_title'], 'saiful'); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="masonry_grid row">
                    <?php 
                    if( !empty( $settings['works'] ) ){
                        foreach( $settings['works'] as $work ){
                            ?>
                        <div class="col-lg-<?php echo esc_attr( $work['work_width'] ); ?> col-md-6 col-sm-12 work_item">
                            <div class="grid_item">
                                <div class="grid_inner_item">
                                    <div class="saiful_img">
                                        <?php $image_alt = get_post_meta( $work['work_image']['id'], '_wp_attachment_image_alt', TRUE );?>
                                        <img src="<?php echo esc_url( $work['work_image']['url'] ) ?>" alt="<?php echo esc_attr( $image_alt );?>">
                                        <div class="overlay_img"></div>
                                        <div class="overlay_content">
                                            <h4><?php echo esc_html__( $work['work_title'], 'saiful'); ?></h4>
                                            <p><?php echo esc_html__( $work['work_subtitle'], 'saiful'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                        }
                    }
                    ?>
                </div>
                <div class="button_box text-center">
                    <a href="<?php echo esc_url( $settings['all_work_link']['url']); ?>" class="saiful_btn"><?php echo esc_html__( $settings['all_work'], 'saiful'); ?></a>
                </div>
            </div>
        </div>
        <!-- End saiful_work section -->
       
        <script>
            jQuery(document).ready(function($){
                 /*---------------------- 
                    Isotope js
                ------------------------*/ 
                $('#work_masonry').imagesLoaded( function() {
                    var $grid = $('.masonry_grid').isotope({
                      itemSelector: '.work_item',
                      masonry: {
                        columnWidth: 1
                      }
                    })
                });
                /*---------------------- 
                    Isotope js
                ------------------------*/
        });
        </script>
        <?php
    }

}
