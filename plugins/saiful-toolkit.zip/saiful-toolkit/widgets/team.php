<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Team_Widgets extends Widget_Base {

    public function get_name() {
        return 'saiful_team';
    }

    public function get_title() {
        return esc_html__('Team', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-users';
    }
    public function get_categories() {
        return ['saiful'];
    }
    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__('Team Members', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Meet Our Team','saiful'),
            'label_block' => true,
            'title' => esc_html__('Enter the section title','saiful'),
                ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'member_name', [
            'label' => esc_html__('Member Name', 'saiful'),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'member_image', [
            'label' => esc_html__('Choose Image', 'shamko'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'member_designation', [
            'label' => esc_html__('Designation', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'fb_link', [
            'label' => esc_html__('Facebook Link', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'twitter_link', [
            'label' => esc_html__('Twitter Link', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'linkedin_link', [
            'label' => esc_html__('LinkedIn Link', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );

        $this->add_control(
                'members',
            [
                'label' => esc_html__('Members', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                        [
                        'member_image' => \Elementor\Utils::get_placeholder_image_src(),
                        'member_name' => esc_html__('Mario Laforas', 'saiful'),
                        'member_designation' => esc_html__('CEO & Founder', 'saiful'),
                        'fb_link' => esc_html__('#', 'saiful'),
                        'twitter_link' => esc_html__('#', 'saiful'),
                        'linkedin_link' => esc_html__('#', 'saiful'),
                    ],
            ],
            'title_field' => '{{{ member_name }}}',
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'member_styles',
                [
                    'label' => esc_html__( 'Team Styling', 'saiful' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
             );
        $this->add_control(
                'section_title_color',
                [
                    'label' => esc_html__('Section Title Color', 'saiful'),
                    'type' => Controls_Manager::COLOR,
                    'title' => esc_html__('Select color','saiful'),
                    'scheme' => [
                        'type' => Scheme_Color::get_type(),
                        'value' => Scheme_Color::COLOR_1,
                ],
                    'selectors' =>
                        [
                        '{{WRAPPER}} .saiful_team .section_title h2' => 'color: {{VALUE}}',
                ],
                'default' => '#04040d',
                    ]
            );
            $this->add_control(
                    'color_scheme',
                    [
                        'label' => esc_html__( 'Color Scheme', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_team .section_title h2:after' => 'background-color: {{VALUE}};',
                                '{{WRAPPER}} .saiful_team_1 .team_slider .grid_inner_item .overlay_img' => 'background: -webkit-linear-gradient( 90deg, {{VALUE}} 0%, {{VALUE}} 66%, {{VALUE}} 100%);',
                        ],
                        'default'   => '-webkit-linear-gradient( 90deg, rgb(29, 173, 53) 0%, rgba(255,128,179,0.34) 66%, rgba(255,255,255,0) 100%)',
                    ]
            );
            $this->add_control(
                    'slider_button_color',
                    [
                        'label' => esc_html__( 'Slider Pagination Button Color', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_team.saiful_team_1 .team_slider .slick-dots li button' => 'background-color: {{VALUE}};',
                        ],
                        'default'   => '#ff0066',
                    ]
            );
            
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.

        $settings = $this->get_settings_for_display();
        ?>
        <!-- Start saiful_team section -->
        <section class="saiful_team saiful_team_1 section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section_title text-center">
                           <?php if (!empty($settings['section_title'])): ?>
                                <h2><?php echo esc_html__($settings['section_title'], 'saiful'); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="team_slider wow slideInUp">
                    <?php
                        if( $settings['members'] ){
                            foreach( $settings['members'] as $member ){
                                ?>
                    <div class="grid_item">
                        <div class="grid_inner_item">
                            <div class="saiful_img">
                                <?php $image_alt = get_post_meta( $member['member_image']['id'], '_wp_attachment_image_alt', TRUE );?>
                                <img src="<?php echo esc_url( $member['member_image']['url'] ) ?>" alt="<?php echo esc_attr( $image_alt );?>">
                                <div class="overlay_img"></div>
                                <div class="overlay_content">
                                    <h4><?php echo esc_html__( $member['member_name'],'saiful' );?></h4>
                                    <p><?php echo esc_html__( $member['member_designation'],'saiful' );?></p>
                                    <ul class="social_link">
                                        <li><a href="<?php echo esc_url( $member['fb_link']['url'] ) ?>"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="<?php echo esc_url( $member['twitter_link']['url'] ) ?>"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="<?php echo esc_url( $member['linkedin_link']['url'] ) ?>"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                                <?php 
                            }
                        }
                    ?>
                </div>
            </div>
        </section>
        <script>
            jQuery(document).ready(function(){
                jQuery('.team_slider').slick({
                    autoplay: false,
                    infinite: true,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    speed: 400,
                    dots: true,
                    arrows: false,
                    responsive: [
                        {
                          breakpoint: 1024,
                          settings: {
                            slidesToShow: 3
                          }
                        },
                        {
                          breakpoint: 991,
                          settings: {
                            slidesToShow: 2
                          }
                        },
                        {
                          breakpoint: 768,
                          settings: {
                            slidesToShow: 1
                          }
                        }
                    ]
            });
        });
        </script>
        <?php
    }

}
