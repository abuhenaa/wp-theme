<?php

namespace Saiful\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class Case_Study_Widgets extends Widget_Base {

    public function get_name() {
        return 'saiful_case_study';
    }

    public function get_title() {
        return esc_html__('Case Study', 'saiful');
    }

    public function get_icon() {
        return 'fas fa-binoculars';
    }
    public function get_categories() {
        return ['saiful'];
    }
    protected function _register_controls() {

        $this->start_controls_section('title_section', [
            'label' => esc_html__('Case Studies', 'saiful'),
                ]
        );
        $this->add_control(
                'section_title', [
            'label' => esc_html__('Section Title', 'saiful'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Our Featured Case Study','saiful'),
            'label_block' => true,
            'title' => esc_html__('Enter the section title','saiful'),
                ]
        );
        $this->add_control(
                'case_slider', [
            'label' => esc_html__('Slider', 'saiful'),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'On', 'saiful' ),
            'label_off' => esc_html__( 'Off', 'saiful' ),
            'return_value' => 'yes',
            'default' => 'yes',
                ]
        );
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'case_title', [
            'label' => esc_html__( 'Case Title', 'saiful' ),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        
        $repeater->add_control(
                'case_image', [
            'label' => esc_html__('Choose Image', 'shamko'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'case_cat', [
            'label' => esc_html__( 'Case Category', 'saiful' ),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
        $repeater->add_control(
                'case_details_link', [
            'label' => esc_html__('Case Details Page link', 'saiful'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'label_block' => true,
                ]
        );
         $repeater->add_control(
                'case_read_more', [
            'label' => esc_html__( 'Read More Text', 'saiful' ),
            'type' => Controls_Manager::TEXT,
            'dynamic' => [
                'active' => true,
            ],
            'default' => esc_html( 'Read More','saiful' ),
            'label_block' => true,
                ]
        );
        $this->add_control(
                'case_studies',
            [
                'label' => esc_html__('Case Studies', 'saiful'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                        [
                        'case_title' => esc_html__('Highlight the key take away', 'saiful'),
                        'case_cat' => esc_html__('Web Design', 'saiful'),
                        'case_details_link' => esc_html__('#', 'saiful'),
                    ],
            ],
            'title_field' => '{{{ case_title }}}',
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'service_styles',
                [
                    'label' => esc_html__( 'Service Styling', 'saiful' ),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
             );
        $this->add_control(
                'section_title_color',
                [
                    'label' => esc_html__('Section Title Color', 'saiful'),
                    'type' => Controls_Manager::COLOR,
                    'title' => esc_html__('Select color','saiful'),
                    'scheme' => [
                        'type' => Scheme_Color::get_type(),
                        'value' => Scheme_Color::COLOR_1,
                ],
                    'selectors' =>
                        [
                        '{{WRAPPER}} .saiful_service .section_title h2' => 'color: {{VALUE}}',
                ],
                'default' => '#04040d',
                    ]
            );
            $this->add_control(
                    'title_color',
                    [
                        'label' => esc_html__( 'Title Color', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_case_study .grid_inner_item .saiful_info h3 a.title' => 'color: {{VALUE}};',
                        ], 
                        'default'   => '#04040d',
                    ]
                       
            );
            $this->add_control(
                    'color_scheme',
                    [
                        'label' => esc_html__( 'Color Scheme', 'saiful' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}} .saiful_case_study .grid_inner_item .overlay_content a.btn_link,.saiful_case_study .section_title h2:after,.case_study_slide .slick-dots li button' => 'background-color: {{VALUE}};',
                                '{{WRAPPER}} .saiful_case_study .grid_inner_item .saiful_info a.tag' => 'color: {{VALUE}};',
                        ], 
                        'default'   => '#ff0066',
                    ]
                       
            );
        $this->end_controls_section();
    }

    protected function render() {

        // get our input from the widget settings.

        $settings = $this->get_settings_for_display();
        ?>

<!-- Start saiful_case_study section -->
        <div class="saiful_case_study case_study_1 section_padding">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section_title text-center">
                            <?php if (!empty($settings['section_title'])): ?>
                                <h2><?php echo esc_html__($settings['section_title'], 'saiful'); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="case_study_slide wow slideInUp">
                    <?php 
                    if( $settings['case_slider'] != 'yes' ){
                        echo '<div class="row">';
                    }
                        if( !empty( $settings['case_studies'] ) ){
                            foreach( $settings['case_studies'] as $case_study ){
                                if( $settings['case_slider'] != 'yes' ){
                                    echo '<div class="col-lg-4 col-md-6 col-sm-12">';
                                }
                               ?>
                            <div class="grid_item">
                                <div class="grid_inner_item">
                                    <div class="saiful_img"> 
                                        <?php $image_alt = get_post_meta( $case_study['case_image']['id'], '_wp_attachment_image_alt', TRUE );?>
                                        <img src="<?php echo esc_url( $case_study['case_image']['url'] ) ?>" class="img-fluid" alt="<?php echo esc_attr( $image_alt );?>">
                                        <div class="overlay_img"></div>
                                        <div class="overlay_content">
                                            <?php 
                                            if( !empty( $case_study['case_details_link'] ) ){
                                                $external_link = $case_study['case_details_link']['is_external'] ? 'target="_blank"' : '';
                                                $nofollow_link = $case_study['case_details_link']['nofollow'] ? 'rel="nofollow"' : '';
                                            }
                                            ?>
                                            <a href="<?php echo esc_url( $case_study['case_details_link']['url']); ?>" class="btn_link" <?php echo esc_attr( $external_link ) . esc_attr( $nofollow_link );  ?>><?php echo esc_html__( $case_study['case_read_more'], 'saiful'); ?></a>
                                        </div>
                                    </div>
                                    <div class="saiful_info">
                                        <a href="#" class="tag"><?php echo esc_html__( $case_study['case_cat'], 'saiful' ); ?></a>
                                        <h3><a href="<?php echo esc_url( $case_study['case_details_link']['url']); ?>" class="title" <?php echo esc_attr( $external_link ) . esc_attr( $nofollow_link );  ?>><?php echo esc_html__( $case_study['case_title'], 'saiful' ); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                            <?php
                            if( $settings['case_slider'] != 'yes' ){
                                    echo '</div>';
                                }
                            }
                        }
                        if( $settings['case_slider'] != 'yes' ){
                        echo '</div>';
                        }
                    ?>
                </div>
            </div>
        </div>
    <?php if( $settings['case_slider'] == 'yes' ){
    ?>
        <script>
            jQuery(document).ready(function($){
               $('.case_study_slide').slick({
                autoplay: false,
                infinite: true,
                slidesToShow: 3,
                slidesToScroll: 1,
                speed: 400,
                dots: true,
                arrows: false,
                responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 2
                      }
                    },
                    {
                      breakpoint: 991,
                      settings: {
                        slidesToShow: 2
                      }
                    },
                    {
                      breakpoint: 768,
                      settings: {
                        slidesToShow: 1
                      }
                    }
                ]
            });   
            });
           
    </script>
     <!-- End saiful _case_study section -->
<?php 
}

    }

}
