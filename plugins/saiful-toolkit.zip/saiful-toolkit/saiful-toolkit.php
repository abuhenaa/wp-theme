<?php

/*
  Plugin Name: Saiful Toolkit
  Description: This is Saiful theme main plugin where all the custom functionalities included. Recommended to activate it.
  Author: CodeAstrology
  Author URI: https://themeforest.net/user/codeastrology
  Version: 1.0.0

 */

//exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
//saiful constant defining 

define('SAIFUL_PLUGIN_URI', WP_PLUGIN_URL . '/' . plugin_basename(__FILE__) . '/');
define('SAIFUL_PLUGIN_PATH', plugin_dir_path(__FILE__));

//included custom functions 
require_once SAIFUL_PLUGIN_PATH . 'inc/custom-functions.php';

//include wp custom widgets
require_once SAIFUL_PLUGIN_PATH . 'inc/recent-posts.php';
require_once SAIFUL_PLUGIN_PATH . 'inc/post-categories.php';


//including  elementor-widgets.php
class ElementorCustomElement {

    private static $instance = null;

    public static function get_instance() {
        if (!self::$instance)
            self::$instance = new self;
        return self::$instance;
    }

    public function init() {
        
        add_action('elementor/widgets/widgets_registered', [$this, 'widgets_registered']);
        add_action('elementor/elements/categories_registered', [$this, 'add_elementor_widget_categories']);
    }
    
    public function add_elementor_widget_categories($elements_manager) {

        $elements_manager->add_category(
                'saiful', [
            'title' => esc_html__('Saiful', 'saiful'),
            'icon' => 'fa fa-plug',
                ]
        );
    }
    
    
    public function widgets_registered() {

        // We check if the Elementor plugin has been installed / activated.
        if ( defined( 'ELEMENTOR_PATH' ) && class_exists( 'Elementor\Widget_Base' ) ) {

            //get wp category list
            function saiful_get_category_options() {
                $categories_list = get_categories();
                $category_option = false;
                if (count($categories_list) > 0) {
                    foreach ($categories_list as $catObject) {
                        $category_option[$catObject->term_id] = $catObject->name;
                    }
                }
                return $category_option;
            }

            //including elementor widgets file

            require_once __DIR__ . '/widgets/services.php';
            require_once __DIR__ . '/widgets/about.php';
            require_once __DIR__ . '/widgets/breadcrumb.php';
            require_once __DIR__ . '/widgets/what-we-do.php';
            require_once __DIR__ . '/widgets/counter.php';
            require_once __DIR__ . '/widgets/team.php';
            require_once __DIR__ . '/widgets/accordion.php';
            require_once __DIR__ . '/widgets/testimonial.php';
            require_once __DIR__ . '/widgets/pricing-table.php';
            require_once __DIR__ . '/widgets/blog.php';
            require_once __DIR__ . '/widgets/case-study.php';
            require_once __DIR__ . '/widgets/masonry-works.php';

            //initailizing all elementor widgets classes 
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Saiful_Services_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\About_Us_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Breadcrumb_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\WWD_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\CounterBox_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Team_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Pricing_Table_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Accordion_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Testimonial_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Blog_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Case_Study_Widgets());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Saiful\Widgets\Masonry_Works_Widgets());
        }
    }

}

ElementorCustomElement::get_instance()->init();


