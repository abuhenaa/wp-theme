<?php
/**
 * In this file all the custom functionality will be here
 * @package Saiful
 */

//date shortcode
function saiful_date_shortcode() {

	return date( 'Y' );

}
add_shortcode( 'saiful_date', 'saiful_date_shortcode' );

//registering custom widgets
function saiful_register_widgets() {
	register_widget( 'Saiful_Recent_Posts' );
	register_widget( 'Saiful_Widget_Categories' );
}
add_action( 'widgets_init', 'saiful_register_widgets' );

//post share function
function saiful_post_share(){
    echo '<div class="post_share">
            <ul>
                <li><a href="https://www.facebook.com/sharer/sharer.php?u='. get_permalink() .'"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="https://twitter.com/home?status='. get_permalink() .'"><i class="fab fa-twitter"></i></a></li>
                <li><a href="https://www.linkedin.com/shareArticle?mini=true&url='. get_permalink() .'"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
        </div>';
}