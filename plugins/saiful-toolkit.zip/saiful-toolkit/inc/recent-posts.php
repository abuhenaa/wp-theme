<?php
class Saiful_Recent_Posts extends WP_Widget {

	public function __construct() {

		parent::__construct(
			'saiful_recent_posts',
			__( 'Saiful Recent Posts', 'saiful' ),
			array(
				'description' => __( 'Most recent posts on site.', 'saiful' ),
				'classname'   => 'recent_news_box',
			)
		);

	}

	public function widget( $args, $instance ) {

		$title  = ( ! empty( $instance['saiful_title']  ) ) ? $instance['saiful_title'] : __( 'Recent Posts' );
		$number = ( ! empty( $instance['saiful_number'] ) ) ? absint( $instance['saiful_number'] ) : 5;
		
		if ( ! $number )
			$number = 5;
		
		// Before widget tag
		echo $args['before_widget'];
		
		// Title
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
		
		// Recent Posts
		$query = new WP_Query( array (
			'posts_per_page'      => $number,
			'ignore_sticky_posts' => true
		) );
		if ( $query->have_posts() ) :
                    while ( $query->have_posts() ) : $query->the_post();
				$post_title = ( get_the_title() ? get_the_title() : get_the_ID() );
		echo '<div class="single_news">
                        <div class="news_thumb">
                            <img src="'.get_the_post_thumbnail_url(null,'thumbnail') .'" class="img-fluid" alt="">
                        </div>
                        <div class="news_info">
                            <h5><a href="' . get_permalink() . '" class="link">'. $post_title .'</a></h5>
                            <a href="#" class="date">'. get_the_date() .'</a>
                        </div>
                    </div>';
			endwhile;
			echo '</ul>';
		
		endif;
		wp_reset_postdata();
		
		// After widget tag
		echo $args['after_widget'];

	}

	public function form( $instance ) {

		// Set default values
		$instance = wp_parse_args( (array) $instance, array( 
			'saiful_title' => '',
			'saiful_number' => '5',
		) );

		// Retrieve an existing value from the database
		$saiful_title = !empty( $instance['saiful_title'] ) ? $instance['saiful_title'] : '';
		$saiful_number = !empty( $instance['saiful_number'] ) ? $instance['saiful_number'] : '';

		// Form fields
		echo '<p>';
		echo '	<label for="' . $this->get_field_id( 'saiful_title' ) . '" class="saiful_title_label">' . __( 'Title', 'saiful' ) . '</label>';
		echo '	<input type="text" id="' . $this->get_field_id( 'saiful_title' ) . '" name="' . $this->get_field_name( 'saiful_title' ) . '" class="widefat" placeholder="' . esc_attr__( '', 'saiful' ) . '" value="' . esc_attr( $saiful_title ) . '">';
		echo '</p>';

		echo '<p>';
		echo '	<label for="' . $this->get_field_id( 'saiful_number' ) . '" class="saiful_number_label">' . __( 'Posts to show', 'saiful' ) . '</label>';
		echo '	<input type="number" id="' . $this->get_field_id( 'saiful_number' ) . '" name="' . $this->get_field_name( 'saiful_number' ) . '" class="widefat" placeholder="' . esc_attr__( '', 'saiful' ) . '" value="' . esc_attr( $saiful_number ) . '">';
		echo '	<span class="description">' . __( 'Number of posts to show.', 'saiful' ) . '</span>';
		echo '</p>';

	}

	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['saiful_title'] = !empty( $new_instance['saiful_title'] ) ? strip_tags( $new_instance['saiful_title'] ) : '';
		$instance['saiful_number'] = !empty( $new_instance['saiful_number'] ) ? strip_tags( $new_instance['saiful_number'] ) : '';

		return $instance;

	}

}
