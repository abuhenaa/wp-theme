<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Saiful
 */

?>

	</div><!-- #content -->
    </div>
         <!-- Start saiful_footer area -->
        <footer class="saiful_footer dark_bg">
            <div class="container">
                <div class="footer_top">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="footer_logo">
                               <?php 
                               the_custom_logo();
                               ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="social_link">
                                <ul>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="#"><i class="fab fa-behance"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="footer_top_content text-center">
                                <?php 
                                    $args = array(
                                        'theme_location' => 'footer-menu',
                                        'menu_class' => 'footer_menu',
                                    );
                                    wp_nav_menu($args);
                                
                                ?>
                                <p>87 London Road Kingston Upon<br>KT44 1HY London, UK</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer_copyright footer_copyright">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="copyright_text text-center">
                                <p>Copyright &copy; 2019 saiful Company. All rights reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End saiful_footer area -->
	<footer id="colophon" class="site-footer">
		<div class="site-info">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'saiful' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Proudly powered by %s', 'saiful' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'saiful' ), 'saiful', '<a href="https://codeastrology.com">Code Astrology</a>' );
				?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
