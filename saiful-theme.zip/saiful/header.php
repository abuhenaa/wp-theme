<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Saiful
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class("header-transparent"); ?>>
    <!-- Start preloader area -->
    <!--<div class="preloader_area">
        <div class="spinner">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
            <div class="line4"></div>
            <div class="line5"></div>
            <div class="line6"></div>
            <div class="line7"></div>
        </div>
    </div>-->
    <!-- End preloader area -->
    <?php 
        $header_version = 'header_area_1 transparent_header';
    ?>
    <div id="page" class="site">
        <!-- Start header_area -->
        <header class="site-header header_area header_area_1 transparent_header">
            <div class="container">
                <div class="site_menu">
                    <div class="row align-items-center">
                        <div class="col-lg-2">
                            <div class="site-branding">
                                <div class="brand_logo">
                                <?php
                                the_custom_logo();
                                ?>
                                </div>
                            </div><!-- .site-branding -->
                        </div>
                        <div class="col-lg-10">
                            <div class="saiful_menu">
                                <?php 
                                    $args = array(
                                        'theme_location' => 'main-menu',
                                        'container' => 'nav',
                                        'container_class' => 'main_menu'
                                    ); 
                                    wp_nav_menu($args); 
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- mobile menu -->
                <div class="mobile_wrapper">
                    <div class="row align-items-center mobile_header">
                        <div class="col-lg-3 col-md-4 col-6">
                            <div class="brand_logo">
                                 <?php
                                    the_custom_logo();
                                 ?>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-8 col-6">
                            <div class="menu_button">
                                <div class="menu_icon">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="sidenav_menu">
                        <div class="close_icon">
                            <a href="#" class="close_btn"><i class="fas fa-times"></i></a>
                        </div>
                        <?php 
                            $args = array(
                                'theme_location' => 'main-menu',
                                'menu_class' => 'sidebar-menu',
                            ); 
                            wp_nav_menu($args); 
                        ?>
                    </div>
                </div>
                <!-- mobile menu -->
            </div>
        </header><!-- End header_area -->
	<div id="content" class="site-content">
